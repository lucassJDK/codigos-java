import java.util.*;
import java.util.Scanner;
import java.util.Arrays;

 class Dcoder
 {
   public static void main(String args[])
   { 
   
    for (int n = 1; n<=10; n++) {
      System.out.println("" + n);
      }
   }
 }
