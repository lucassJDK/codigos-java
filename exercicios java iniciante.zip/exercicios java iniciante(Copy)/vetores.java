import java.util.*;
import java.util.Scanner;
import java.util.Arrays;

 class vetor
 {
   public static void main(String args[])
   { 
     Scanner scan = new Scanner(System.in);
    System.out.println("insira 10 números inteiros");
    int n [] = new int[10];
    for ( int lista = 0; lista < n.length; lista++) {
    n [lista] = scan.nextInt();
    }
    
   }
 }
