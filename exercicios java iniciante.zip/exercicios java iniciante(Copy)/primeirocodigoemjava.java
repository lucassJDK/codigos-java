import java.util.*;
import java.util.Scanner;


 class main
 {
   public static void main(String args[])
   { 
    System.out.println("João esta jogando volleyball");
    System.out.println("ele faz 10 saques,e depois de 30 minutos \n fez mais 5.Quantos saques João fez");
    
    Scanner scan = new Scanner (System.in);
    int saques = scan.nextInt();
   }
 }
